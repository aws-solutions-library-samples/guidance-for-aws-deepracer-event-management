// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from deepracer_interfaces_pkg:srv/EnableOfftrackSrv.idl
// generated code does not contain a copyright notice

#ifndef DEEPRACER_INTERFACES_PKG__SRV__DETAIL__ENABLE_OFFTRACK_SRV__BUILDER_HPP_
#define DEEPRACER_INTERFACES_PKG__SRV__DETAIL__ENABLE_OFFTRACK_SRV__BUILDER_HPP_

#include "deepracer_interfaces_pkg/srv/detail/enable_offtrack_srv__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace deepracer_interfaces_pkg
{

namespace srv
{

namespace builder
{

class Init_EnableOfftrackSrv_Request_enable
{
public:
  Init_EnableOfftrackSrv_Request_enable()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::deepracer_interfaces_pkg::srv::EnableOfftrackSrv_Request enable(::deepracer_interfaces_pkg::srv::EnableOfftrackSrv_Request::_enable_type arg)
  {
    msg_.enable = std::move(arg);
    return std::move(msg_);
  }

private:
  ::deepracer_interfaces_pkg::srv::EnableOfftrackSrv_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::deepracer_interfaces_pkg::srv::EnableOfftrackSrv_Request>()
{
  return deepracer_interfaces_pkg::srv::builder::Init_EnableOfftrackSrv_Request_enable();
}

}  // namespace deepracer_interfaces_pkg


namespace deepracer_interfaces_pkg
{

namespace srv
{

namespace builder
{

class Init_EnableOfftrackSrv_Response_error
{
public:
  explicit Init_EnableOfftrackSrv_Response_error(::deepracer_interfaces_pkg::srv::EnableOfftrackSrv_Response & msg)
  : msg_(msg)
  {}
  ::deepracer_interfaces_pkg::srv::EnableOfftrackSrv_Response error(::deepracer_interfaces_pkg::srv::EnableOfftrackSrv_Response::_error_type arg)
  {
    msg_.error = std::move(arg);
    return std::move(msg_);
  }

private:
  ::deepracer_interfaces_pkg::srv::EnableOfftrackSrv_Response msg_;
};

class Init_EnableOfftrackSrv_Response_is_active
{
public:
  Init_EnableOfftrackSrv_Response_is_active()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EnableOfftrackSrv_Response_error is_active(::deepracer_interfaces_pkg::srv::EnableOfftrackSrv_Response::_is_active_type arg)
  {
    msg_.is_active = std::move(arg);
    return Init_EnableOfftrackSrv_Response_error(msg_);
  }

private:
  ::deepracer_interfaces_pkg::srv::EnableOfftrackSrv_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::deepracer_interfaces_pkg::srv::EnableOfftrackSrv_Response>()
{
  return deepracer_interfaces_pkg::srv::builder::Init_EnableOfftrackSrv_Response_is_active();
}

}  // namespace deepracer_interfaces_pkg

#endif  // DEEPRACER_INTERFACES_PKG__SRV__DETAIL__ENABLE_OFFTRACK_SRV__BUILDER_HPP_
