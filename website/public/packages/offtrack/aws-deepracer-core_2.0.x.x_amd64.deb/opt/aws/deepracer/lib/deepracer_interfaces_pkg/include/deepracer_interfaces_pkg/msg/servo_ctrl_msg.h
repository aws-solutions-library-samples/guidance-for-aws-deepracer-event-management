// generated from rosidl_generator_c/resource/idl.h.em
// with input from deepracer_interfaces_pkg:msg/ServoCtrlMsg.idl
// generated code does not contain a copyright notice

#ifndef DEEPRACER_INTERFACES_PKG__MSG__SERVO_CTRL_MSG_H_
#define DEEPRACER_INTERFACES_PKG__MSG__SERVO_CTRL_MSG_H_

#include "deepracer_interfaces_pkg/msg/detail/servo_ctrl_msg__struct.h"
#include "deepracer_interfaces_pkg/msg/detail/servo_ctrl_msg__functions.h"
#include "deepracer_interfaces_pkg/msg/detail/servo_ctrl_msg__type_support.h"

#endif  // DEEPRACER_INTERFACES_PKG__MSG__SERVO_CTRL_MSG_H_
