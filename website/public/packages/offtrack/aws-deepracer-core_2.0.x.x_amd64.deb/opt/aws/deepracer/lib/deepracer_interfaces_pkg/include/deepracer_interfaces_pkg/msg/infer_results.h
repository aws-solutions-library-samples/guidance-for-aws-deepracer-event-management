// generated from rosidl_generator_c/resource/idl.h.em
// with input from deepracer_interfaces_pkg:msg/InferResults.idl
// generated code does not contain a copyright notice

#ifndef DEEPRACER_INTERFACES_PKG__MSG__INFER_RESULTS_H_
#define DEEPRACER_INTERFACES_PKG__MSG__INFER_RESULTS_H_

#include "deepracer_interfaces_pkg/msg/detail/infer_results__struct.h"
#include "deepracer_interfaces_pkg/msg/detail/infer_results__functions.h"
#include "deepracer_interfaces_pkg/msg/detail/infer_results__type_support.h"

#endif  // DEEPRACER_INTERFACES_PKG__MSG__INFER_RESULTS_H_
