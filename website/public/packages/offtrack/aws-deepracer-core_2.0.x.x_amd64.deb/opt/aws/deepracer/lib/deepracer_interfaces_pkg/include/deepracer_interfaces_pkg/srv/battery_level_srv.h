// generated from rosidl_generator_c/resource/idl.h.em
// with input from deepracer_interfaces_pkg:srv/BatteryLevelSrv.idl
// generated code does not contain a copyright notice

#ifndef DEEPRACER_INTERFACES_PKG__SRV__BATTERY_LEVEL_SRV_H_
#define DEEPRACER_INTERFACES_PKG__SRV__BATTERY_LEVEL_SRV_H_

#include "deepracer_interfaces_pkg/srv/detail/battery_level_srv__struct.h"
#include "deepracer_interfaces_pkg/srv/detail/battery_level_srv__functions.h"
#include "deepracer_interfaces_pkg/srv/detail/battery_level_srv__type_support.h"

#endif  // DEEPRACER_INTERFACES_PKG__SRV__BATTERY_LEVEL_SRV_H_
