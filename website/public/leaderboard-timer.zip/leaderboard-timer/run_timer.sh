#!/usr/bin/env bash

while true; do node timer.js; done